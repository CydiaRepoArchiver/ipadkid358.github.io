#import <Preferences/Preferences.h>

@interface redditprefs: PSListController {
}
@end

@implementation redditprefs
- (id)specifiers {
	if(_specifiers == nil) {
		_specifiers = [[self loadSpecifiersFromPlistName:@"redditprefs" target:self] retain];
	}
	return _specifiers;
}
- (void)link {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=3CQVMCZMLBFK2&lc=US&item_name=Breddit%202&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted"]];
}
@end

// vim:ft=objc
