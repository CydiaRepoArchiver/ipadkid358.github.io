//
//  Created by Marco Arment on 2014-04-06.
//  Copyright (c) 2014 Marco Arment. See included LICENSE file.
//

#import "NSLayoutConstraint+CompactConstraint.h"

/**
If you need help with CompactConstraints refer to Marco Arments readme to learn how to use it.
https://github.com/marcoarment/CompactConstraint/blob/master/README.md
**/

@interface UIView (CompactConstraint)

// Add a single constraint with the compact syntax
- (NSLayoutConstraint *)catalyst_addCompactConstraint:(NSString *)relationship metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views;

// Add any number of constraints. Can also mix in Visual Format Language strings.
- (NSArray *)catalyst_addCompactConstraints:(NSArray *)relationshipStrings metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views;

// And a convenient shortcut for what we always end up doing with the visualFormat call.
- (void)catalyst_addConstraintsWithVisualFormat:(NSString *)format options:(NSLayoutFormatOptions)opts metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views;

@end
