//
//
//    CatalystImage.h
//    Fast Image Creation
//    Created by CP Digital Darkroom <tweaks@cpdigitaldarkroom.support> 06/26/2016
//    © CP Digital Darkroom <tweaks@cpdigitaldarkroom.support>. All rights reserved.
//
//
//

@interface CatalystImage : NSObject
+ (UIImage*)imageFromView:(UIView*)view;
+ (UIImage*)imageFromBaseView:(UIView*)baseView andTopView:(UIView*)topView;
@end
