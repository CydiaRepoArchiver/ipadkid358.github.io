//
//
//    Catalyst.h
//    Fast SpringBoard Shit
//    Created by CP Digital Darkroom <tweaks@cpdigitaldarkroom.support> 06/26/2016
//    © CP Digital Darkroom <tweaks@cpdigitaldarkroom.support>. All rights reserved.
//
//
//

#import "CatalystImage.h"
#import "CatalystSnapshot.h"
#import "../../CompactConstraint/CompactConstraint.h"

@interface Catalyst : NSObject

+ (NSString *)displayNameForAppIdentifier:(NSString *)identifier;

+ (UIImage *)appIconImageForAppIdentifier:(NSString *)identifier;

+ (UIImage *)appIconImageFromImage:(UIImage *)image;

+ (void)closeAppWithIdentifier:(NSString *)identifier;

+ (void)openApplicationWithIdentifier:(NSString *)identifier suspended:(BOOL)suspended;

@end
