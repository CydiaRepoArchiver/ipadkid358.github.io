//
//  Created by Marco Arment on 2014-04-06.
//  Copyright (c) 2014 Marco Arment. See included LICENSE file.
//

/**
If you need help with CompactConstraints refer to Marco Arments readme to learn how to use it.
https://github.com/marcoarment/CompactConstraint/blob/master/README.md
**/

@interface NSLayoutConstraint (CompactConstraint)

+ (instancetype)catalyst_compactConstraint:(NSString *)relationship metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views self:(id)selfView;

+ (NSArray <NSLayoutConstraint *> *)catalyst_compactConstraints:(NSArray <NSString *> *)relationshipStrings metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views self:(id)selfView;

+ (NSArray *)catalyst_identifiedConstraintsWithVisualFormat:(NSString *)format options:(NSLayoutFormatOptions)opts metrics:(NSDictionary <NSString *, NSNumber *> *)metrics views:(NSDictionary <NSString *, UIView *> *)views;

@end
