//
//
//    CatalystSnapshot.h
//    Fast snapshot creation
//    Created by CP Digital Darkroom <tweaks@cpdigitaldarkroom.support> 06/26/2016
//    © CP Digital Darkroom <tweaks@cpdigitaldarkroom.support>. All rights reserved.
//
//
//

@interface CatalystSnapshot : NSObject

+ (instancetype)sharedProvider;

+ (UIImage*)imageFromView:(UIView*)view;

+ (UIImage*)imageFromBaseView:(UIView*)baseView andTopView:(UIView*)topView;

- (UIView *)snapshotViewForAppIdentifier:(NSString *)appIdentifier;

- (UIImage *)snapshotImageForAppIdentifier:(NSString *)appIdentifier;

- (void)refreshSnapshotForAppIdentifier:(NSString *)appIdentifier;

- (void)setSnapshotImage:(UIImage *)snapshot forAppIdentifier:(NSString *)appIdentifier;

- (void)setupSnapshots;

@end
