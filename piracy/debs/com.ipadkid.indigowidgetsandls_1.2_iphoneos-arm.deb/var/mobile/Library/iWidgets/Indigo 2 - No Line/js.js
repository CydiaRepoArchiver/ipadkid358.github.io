$(document).ready(function() {

    //color stuff
    if (darkMode) {
      $('html').css({'color':'black'})
      $('#line').css({'background-color':'transparent'})
    }
    else {
      $('html').css({'color':'white'})
      $('#line').css({'background-color':'transparent'})
    }

setInterval(function() {
    //Date stuff
    var dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

    // Create a newDate() object
    var newDate = new Date();
    // Extract the current date from Date object
    newDate.setDate(newDate.getDate());
    // Output the day, date, month and year
    var day = dayNames[newDate.getDay()]
    var num = newDate.getDate()

    // this is for adding the ordinal suffix, turning 1, 2 and 3 into 1st, 2nd and 3rd
    Number.prototype.addSuffix = function() {
        var n = this.toString().split('.')[0];
        var lastDigits = n.substring(n.length - 2);
        //add exception just for 11, 12 and 13
        if (lastDigits === '11' || lastDigits === '12' || lastDigits === '13') {
            return this + 'th';
        }
        switch (n.substring(n.length - 1)) {
            case '1':
                return this + 'st';
            case '2':
                return this + 'nd';
            case '3':
                return this + 'rd';
            default:
                return this + 'th';
        }
    };


    var o = num.addSuffix()
    var or = o.split(num)
    var ord = or[1]
    $('#date').html(day.toLowerCase() + ' the '+ num + ord);
}, 500);

// time stuff
if (twelve == false) {
    setInterval(function() {
        // Create a newDate() object and extract the minutes of the current time on the visitor's
        var minutes = new Date().getMinutes();
        // Add a leading zero to the minutes value
        $("#m").html((minutes < 10 ? "0" : "") + minutes);
    }, 100);

    setInterval(function() {
        // Create a newDate() object and extract the hours of the current time on the visitor's
        var hours = new Date().getHours();
        // Add a leading zero to the hours value
        $("#h").html((hours < 10 ? "0" : "") + hours);
    }, 100);
} else if (twelve == true){
  $('#time').css({'padding-left':'10px'});
  setInterval(function() {
      // Create a newDate() object and extract the minutes of the current time on the visitor's
      var minutes = new Date().getMinutes();
      var hours = new Date().getHours();
      suffix = (hours >= 12)? 'PM' : 'AM';
      // Add a leading zero to the minutes value
      $("#m").html((minutes < 10 ? "0" : "") + minutes + '<span id="suffix">' + suffix + '</span>');
  }, 100);

  setInterval(function() {
      // Create a newDate() object and extract the hours of the current time on the visitor's
      var hours = new Date().getHours();

      //only -12 from hours if it is greater than 12 (if not back at mid night)
      hours = (hours > 12)? hours -12 : hours;

      //if 00 then it is 12 am
      hours = (hours == '00')? 12 : hours;
      // Add a leading zero to the hours value
      $("#h").html(hours);
  }, 100);
}

});
