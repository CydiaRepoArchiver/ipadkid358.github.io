#!/bin/bash

a=0
while ((a < 10))
do
 b=0
 while ((b < 10))
 do
  b=$((b+1))
 done
 a=$((a+1))
done
