#!/bin/bash

a=0
while ((a < 10))
do
 b=0
 while ((b < 10))
 do
  c=0
  while ((c < 10))
  do
  c=$((c+1))
  done
  b=$((b+1))
 done
 a=$((a+1))
done
