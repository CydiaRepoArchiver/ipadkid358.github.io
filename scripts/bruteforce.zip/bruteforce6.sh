#!/bin/bash

a=0
while ((a < 10))
do
 b=0
 while ((b < 10))
 do
  c=0
  while ((c < 10))
  do
   d=0
   while ((d < 10))
   do
    e=0
    while ((e < 10))
    do
    f=0
     while ((f < 10))
     do
     f=$((f+1))
     done
    e=$((e+1))
    done
   d=$((d+1))
   done
  c=$((c+1))
  done
  b=$((b+1))
 done
 a=$((a+1))
done
